<?php

/**
 * Plugin Name: Newshub CCRE Plugin
 * Plugin URI: http://www.ibm.com
 * Description: This is a plugin that allows get data from CCRE using JQuery Ajax functionality in WordPress
 * Version: 1.0.0
 * Author: Umesh kumar
 * License: IBM
 **/

	define( 'NHCCRE_PATH', dirname(__FILE__) . '/' );



	class CCREIntegration{
		public static function javascript() {
			global $wp_query;
			wp_reset_query();
			if ( ! is_front_page() && ( is_page() || is_single() || is_search()) ) {
				wp_register_script('ccre_ajax', plugins_url( 'js/ccre_ajax.js', __FILE__ ));

				$post_id = get_the_ID();

				$post_categories = wp_get_post_categories( $post_id );
				$cats = array();
				     
				if(!empty($post_categories)){
					foreach($post_categories as $c){
					    $cat = get_category( $c );
					    $cats[] = array( 'name' => $cat->name, 'slug' => $cat->slug );
					}					
				}else if(is_search()){
					$search_query = get_search_query();
					array_push($cats, $search_query);
				}
				


				$ccre_params = array(
					'url' => "http://cpedevelopmentJAVA.mybluemix.net/freetextrec",
					'postid' => $post_id,
					'string_temp' => $cats
				);

				if(is_ssl()){
					$ccre_params['url'] = "https://cpedevelopmentJAVA.mybluemix.net/freetextrec";
				}
				wp_localize_script('ccre_ajax', 'ccre_params', $ccre_params);

				wp_enqueue_script( 'ccre_ajax', plugins_url( 'js/ccre_ajax.js', __FILE__ ), array('jquery'), '1.0', true );
			}
		}

		public static function widget(){	
			register_widget( 'CCRE_Widget' );		
		}
	}


	add_action( 'wp_head', 'CCREIntegration::javascript' );

	// Widget
	include_once( NHCCRE_PATH . 'widget.php' );
	add_action( 'widgets_init', 'CCREIntegration::widget' );

?>