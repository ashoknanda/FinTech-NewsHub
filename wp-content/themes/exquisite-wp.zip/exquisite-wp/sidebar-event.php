<aside class="sidebar three columns">
	<?php dynamic_sidebar('event'); ?>
</aside>