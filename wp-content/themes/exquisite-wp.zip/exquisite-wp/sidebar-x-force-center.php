<aside class="sidebar three columns">
	<?php 
	
		##############################################################################
		# Topics Sidebar
		##############################################################################
	
	 	?>
	<?php dynamic_sidebar('xforce_center'); ?>
</aside>