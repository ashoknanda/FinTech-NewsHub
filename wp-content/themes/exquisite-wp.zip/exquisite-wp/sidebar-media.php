<aside class="sidebar three columns">
	<?php 
	
		##############################################################################
		# Media Details Sidebar
		##############################################################################
	
	 	?>
	<?php dynamic_sidebar('media'); ?>
</aside>