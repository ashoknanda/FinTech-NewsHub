<!-- Start SearchForm -->
<form method="get" id="searchform" action="<?php echo home_url(); ?>/">
    <fieldset>
    	<input name="s" type="text" id="s" placeholder="<?php _e( 'Search', THB_THEME_NAME ); ?>" class="twelve">
    </fieldset>
</form>
<!-- End SearchForm -->